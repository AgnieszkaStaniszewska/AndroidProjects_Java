package com.example.zajecia_1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    TextView tvWiadomosc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        tvWiadomosc=(TextView) findViewById(R.id.tvWiadomosc);

        Bundle bundle = getIntent().getExtras();
        if(bundle != null) {
            String wiadomosc = bundle.getString("wiadomosc");
            String imie = bundle.getString("imie");
            String nazwisko = bundle.getString("waga");
            int waga = bundle.getInt("waga");
            int wiek = bundle.getInt("wiek");
            String poczta = bundle.getString("poczta");

            tvWiadomosc.setText(wiadomosc + "\n" + imie + " " + nazwisko + ", " + wiek + " lat, waga: " + waga + "kg, poczta: " + poczta);
        }

    }
}