package com.example.zajecia_1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    Button btnAktywnosc1;
    EditText tekst;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnAktywnosc1=(Button)findViewById(R.id.BTN_wyslij);
        tekst=findViewById(R.id.ET_wiadomosc);

        btnAktywnosc1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent NAktywnosc = new Intent(view.getContext(),MainActivity2.class);
                NAktywnosc.putExtra("wiadomosc", tekst.getText().toString());
                NAktywnosc.putExtra("imie", "Adam");
                NAktywnosc.putExtra("waga", 75);
                NAktywnosc.putExtra("nazwisko","Kowalski");
                NAktywnosc.putExtra("wiek", 18);
                NAktywnosc.putExtra("poczta", "98-857");
                startActivity(NAktywnosc);
            }
        });


    }
}