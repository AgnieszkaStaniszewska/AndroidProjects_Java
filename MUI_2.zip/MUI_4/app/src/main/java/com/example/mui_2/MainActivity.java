package com.example.mui_2;

import static android.content.ContentValues.TAG;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
    private RequestQueue mRequestQueue;
    private StringRequest mStringRequest;
    private String url = "https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/timeline/Lodz%2C%20Poland?unitGroup=metric&key=NREEW7VTJZYK4JLPMRF4JCSA8&contentType=json";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getData();

        Button button = (Button) findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MapActivity.class);
                startActivity(intent);

            }
        });
    }



    private void getData() {
        // RequestQueue initialized
        mRequestQueue = Volley.newRequestQueue(this);

        // String Request initialized
        mStringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                Log.i(TAG, "Response :" + response.toString());
                Toast.makeText(getApplicationContext(), "Response :" + response.toString(), Toast.LENGTH_LONG).show();//display the response on screen

                try {
                    JSONObject jObject = new JSONObject(response);

                    String aJsonString1 = jObject.getString("address");
                    String aJsonString2 = jObject.getString("latitude");
                    String aJsonString3 = jObject.getString("longitude");
                    String aJsonString4 = jObject.getString("timezone");
                    String aJsonString5 = jObject.getString("description");

                    TextView textView1 = findViewById(R.id.textView1);
                    TextView textView2 = findViewById(R.id.textView2);
                    TextView textView3 = findViewById(R.id.textView3);
                    TextView textView4 = findViewById(R.id.textView4);
                    TextView textView5 = findViewById(R.id.textView5);

                    textView1.setText(aJsonString1);
                    textView2.setText(aJsonString2);
                    textView3.setText(aJsonString3);
                    textView4.setText(aJsonString4);
                    textView5.setText(aJsonString5);

                } catch (JSONException e) {
                    throw new RuntimeException(e);
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.i(TAG, "Error :" + error.toString());
               // JSONObject jObject = new JSONObject(result);
            }
        });

        mRequestQueue.add(mStringRequest);
    }
}
