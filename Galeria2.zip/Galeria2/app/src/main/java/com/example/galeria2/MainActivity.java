package com.example.galeria2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

public class MainActivity extends AppCompatActivity {
    ImageView imageView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        LinearLayout linearLayout = findViewById(R.id.linearLayout);
        imageView = (ImageView) findViewById(R.id.imageView);
        for(int i=0; i<10; i++)
        {
            ImageView localView = new ImageView(this);
            localView.setLayoutParams(new ViewGroup.LayoutParams(200,200));
            localView.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            int resID = getResources().getIdentifier("r"+i, "drawable",getPackageName());
            localView.setImageResource(resID);
            localView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                ImageView localView = (ImageView) view;
                imageView.setImageDrawable(localView.getDrawable());
            }});
            linearLayout.addView(localView);
        }
    }
}