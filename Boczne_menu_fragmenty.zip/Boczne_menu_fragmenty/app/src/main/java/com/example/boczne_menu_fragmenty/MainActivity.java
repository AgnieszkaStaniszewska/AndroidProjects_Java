package com.example.boczne_menu_fragmenty;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.os.Bundle;
import android.view.MenuItem;

import com.google.android.material.navigation.NavigationView;

public class MainActivity extends AppCompatActivity {

    private DrawerLayout mlayaut;
    private ActionBarDrawerToggle mtoggle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mlayaut=(DrawerLayout) findViewById(R.id.activity_main);
        mtoggle = new ActionBarDrawerToggle(this,mlayaut,R.string.open,R.string.close);
        mlayaut.addDrawerListener(mtoggle);
        NavigationView mnawigacja = (NavigationView) findViewById(R.id.nawigacja);
        mtoggle.syncState();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        ustawContent(mnawigacja);

    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        if(mtoggle.onOptionsItemSelected(item)){
            return true;}
        return super.onOptionsItemSelected(item);
    }

    private void ustawContent (NavigationView navigationView)
    {
        navigationView.setNavigationItemSelectedListener
                (new NavigationView.OnNavigationItemSelectedListener() {
                    @Override
                    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                        return false;
                    }
                });
    }

    public void wybranyElementMenu (MenuItem menuItem)
    {
        Fragment mfragment = null;
        Class fragmentClass;
        switch (menuItem.getItemId())
        {
            case R.id.o_nas:
                fragmentClass=O_nas.class;
                break;
            case R.id.menu:
                fragmentClass=Menu.class;
                break;
            case R.id.galeria:
                fragmentClass=Galeria.class;
                break;
            case R.id.kontakt:
                fragmentClass=MapsFragment.class;
                break;
            default:
                fragmentClass=O_nas.class;
        }
        try {
            mfragment=(Fragment) fragmentClass.newInstance();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction().replace(R.id.fragmentContent,mfragment).commit();
        menuItem.setChecked(true);
        setTitle(menuItem.getTitle());
        mlayaut.closeDrawers();

    }

}