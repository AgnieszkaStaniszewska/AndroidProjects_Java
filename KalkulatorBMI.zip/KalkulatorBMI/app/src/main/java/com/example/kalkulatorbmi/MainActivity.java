package com.example.kalkulatorbmi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Button btnOblicz1;
    EditText tekstH;
    EditText tekstM;
    double wynik;
    TextView tv_Wynik;
    TextView tv_info;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tekstM = findViewById(R.id.PT_Masa);
        tekstH=findViewById(R.id.PT_Wzrost);
        btnOblicz1=findViewById(R.id.BTN_Oblicz);
        tv_Wynik = findViewById(R.id.tv_Wynik);
        tv_info = findViewById(R.id.tv_info);

        btnOblicz1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double wzrost = Double.parseDouble(tekstH.getText().toString());
                double waga = Double.parseDouble(tekstM.getText().toString());
                wynik = waga / (wzrost * wzrost);

               tv_Wynik.setText("Twoje BMI wynosi: "+ wynik);
                if (wynik < 18.5) {
                    tv_info.setText("Niedowaga");
                } else if (wynik >= 18.5 && wynik < 25) {
                    tv_info.setText("Norma");
                } else if (wynik >= 25 && wynik < 30){
                    tv_info.setText("Nadwaga");
                } else {
                    tv_info.setText("Otyłość");
                }
            }
        });
    }
}